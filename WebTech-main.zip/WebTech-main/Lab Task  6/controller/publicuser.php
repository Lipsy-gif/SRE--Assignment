<!DOCTYPE html>  
 <html>  
      <head> 
      <title>Home</title>  
           <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>  
           <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />  
           <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script> 
        <title></title>  
        <div class="container" >
            <h1 class="bg-success text-center text-white p-2 m-3 rounded" >Public User</h1>
            
        </div>
    <div class="relative" position ="relative" left = "30px" text align="center" > 
                              <h3>
                               <a href = home.php>Home</a>
                               <a href = index.php>Login</a> 
                               <a href = registration.php>Registration</a></h3>
    </div> 
          
      </head>  
        
 </html> 
 <br><br>