<?php  
 
 echo '
 
 
 <header>
   <h2></h2>
   
   <a href="login.php">LOGIN</a> |
   <a href="register.php">REGISTRATION</a> 
 </header> ';
 
  
 
  ?>