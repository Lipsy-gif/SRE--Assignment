<!DOCTYPE html>
<html>
  <body>
   
    <form method="post" action="../controller/findproduct.php">
      <h1>SEARCH FOR PRODUCTS</h1>
      <input type="text" name="user_name" required/>
      <input type="submit" name="findUser" value="Search"/>
    </form>
 
  </body>
</html>