<?php 

require_once ('../model/model.php');

function fetchAllProducts(){
	return showAllProducts();

}
function fetchproduct($id){
	return showPrduct($id);

}