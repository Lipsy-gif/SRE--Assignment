<?php
echo '
<footer>
 <p>Copyright &copy; 1999.</p>
</footer>'

?>