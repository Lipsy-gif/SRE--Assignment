<!DOCTYPE html>
<html lang="en">
<head>
    
    <title>Change Profile Picture</title>
    
</head>
<body>
    <div class="img">
        <form  class="upload-form">
            <h2>Profile Picture</h2>
            <img src="img.png" alt="picture">
            <input class="upload-file"  type="file" accept="image/png,image/jpeg"><br><br>
            <hr>
            <input type=submit>
        </form>
    </div>
</body>
</html>